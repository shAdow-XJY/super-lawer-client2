const getters ={
	tabBarList: state =>state.tabBar.tabBarList,
	role:state => state.tabBar.role
}

export default getters